import tkinter as tk
from tkinter import ttk, messagebox
from abc import ABC, abstractmethod

class Producto(ABC):
    def __init__(self, nombre, precio, stock):
        self.nombre = nombre
        self.precio = float(precio)
        self.stock = int(stock)

    @abstractmethod
    def descripcion(self):
        pass

    def calcular_descuento(self, descuento=0, cupon=0, cliente_premium=False):
        descuento = max(0.0, float(descuento))
        cupon = max(0.0, float(cupon))
        premium_extra = 5.0 if cliente_premium else 0.0
        return min(descuento + cupon + premium_extra, 100.0)

    def calcular_precio_final(self, descuento=0, cupon=0, cliente_premium=False):
        porcentaje = self.calcular_descuento(descuento, cupon, cliente_premium)
        return round(self.precio * (1 - porcentaje / 100), 2)


class ProductoElectronico(Producto):
    def __init__(self, nombre, precio, stock, marca, garantia_meses, depreciacion=8):
        super().__init__(nombre, precio, stock)
        self.marca = marca
        self.garantia_meses = int(garantia_meses)
        self.depreciacion = float(depreciacion)

    def descripcion(self):
        return f"Electronics | Name: {self.nombre} | Brand: {self.marca} | Price: ${self.precio:.2f} | Warranty: {self.garantia_meses} months | Stock: {self.stock}"

    def calcular_descuento(self, descuento=0, cupon=0, cliente_premium=False):
        descuento = max(0.0, float(descuento))
        cupon = max(0.0, float(cupon))
        premium_extra = 3.0 if cliente_premium else 0.0
        total = descuento + cupon + premium_extra + self.depreciacion
        return min(total, 45.0)


class ProductoAlimento(Producto):
    def __init__(self, nombre, precio, stock, categoria, dias_para_vencer):
        super().__init__(nombre, precio, stock)
        self.categoria = categoria
        self.dias_para_vencer = int(dias_para_vencer)

    def descripcion(self):
        return f"Food | Name: {self.nombre} | Category: {self.categoria} | Price: ${self.precio:.2f} | Expires in: {self.dias_para_vencer} days | Stock: {self.stock}"

    def calcular_descuento(self, descuento=0, cupon=0, cliente_premium=False):
        descuento = max(0.0, float(descuento))
        cupon = max(0.0, float(cupon))
        premium_extra = 2.0 if cliente_premium else 0.0
        urgencia = 5.0 if self.dias_para_vencer <= 7 else 0.0
        total = descuento + cupon + premium_extra + urgencia
        return min(total, 20.0)


class ProductoRopa(Producto):
    def __init__(self, nombre, precio, stock, talla, temporada):
        super().__init__(nombre, precio, stock)
        self.talla = talla
        self.temporada = temporada

    def descripcion(self):
        return f"Clothing | Name: {self.nombre} | Size: {self.talla} | Season: {self.temporada} | Price: ${self.precio:.2f} | Stock: {self.stock}"

    def calcular_descuento(self, descuento=0, cupon=0, cliente_premium=False):
        descuento = max(0.0, float(descuento))
        cupon = max(0.0, float(cupon))
        premium_extra = 10.0 if cliente_premium else 0.0
        temporada_extra = 15.0 if self.temporada.strip().lower() in {"old", "previous", "clearance"} else 0.0
        total = descuento + cupon + premium_extra + temporada_extra
        return min(total, 70.0)


class CarritoDeCompras:
    def __init__(self):
        self.items = []

    def agregar_producto(self, producto, cantidad=1, descuento=0, cupon=0, cliente_premium=False):
        cantidad = int(cantidad)
        if cantidad <= 0:
            raise ValueError("Quantity must be greater than zero.")
        if cantidad > producto.stock:
            raise ValueError("Insufficient stock.")
        producto.stock -= cantidad
        self.items.append((producto, cantidad, float(descuento), float(cupon), bool(cliente_premium)))

    def obtener_descripciones(self):
        descripciones = []
        for producto, cantidad, descuento, cupon, premium in self.items:
            precio_final = producto.calcular_precio_final(descuento, cupon, premium)
            subtotal = round(precio_final * cantidad, 2)
            descripciones.append(
                f"{producto.descripcion()} | Qty: {cantidad} | Discount: {producto.calcular_descuento(descuento, cupon, premium):.2f}% | Unit Final Price: ${precio_final:.2f} | Subtotal: ${subtotal:.2f}"
            )
        return descripciones

    def calcular_total(self):
        total = 0.0
        for producto, cantidad, descuento, cupon, premium in self.items:
            total += producto.calcular_precio_final(descuento, cupon, premium) * cantidad
        return round(total, 2)

    def vaciar(self):
        self.items.clear()


class TiendaVirtualApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Virtual Store System")
        self.root.geometry("980x640")
        self.carrito = CarritoDeCompras()
        self._build_ui()
        self._update_extra_fields()

    def _build_ui(self):
        main = ttk.Frame(self.root, padding=15)
        main.pack(fill="both", expand=True)

        form = ttk.LabelFrame(main, text="Product Registration", padding=15)
        form.pack(fill="x")

        ttk.Label(form, text="Product Type").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        ttk.Label(form, text="Name").grid(row=0, column=2, sticky="w", padx=5, pady=5)
        ttk.Label(form, text="Price").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        ttk.Label(form, text="Stock").grid(row=1, column=2, sticky="w", padx=5, pady=5)
        ttk.Label(form, text="Quantity").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        ttk.Label(form, text="Discount %").grid(row=2, column=2, sticky="w", padx=5, pady=5)
        ttk.Label(form, text="Coupon %").grid(row=3, column=0, sticky="w", padx=5, pady=5)

        self.tipo_var = tk.StringVar(value="Electronics")
        self.nombre_var = tk.StringVar()
        self.precio_var = tk.StringVar()
        self.stock_var = tk.StringVar()
        self.cantidad_var = tk.StringVar(value="1")
        self.descuento_var = tk.StringVar(value="0")
        self.cupon_var = tk.StringVar(value="0")
        self.premium_var = tk.BooleanVar(value=False)
        self.extra1_var = tk.StringVar()
        self.extra2_var = tk.StringVar()

        self.tipo_combo = ttk.Combobox(form, textvariable=self.tipo_var, values=["Electronics", "Food", "Clothing"], state="readonly", width=22)
        self.tipo_combo.grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        self.tipo_combo.bind("<<ComboboxSelected>>", lambda event: self._update_extra_fields())

        ttk.Entry(form, textvariable=self.nombre_var, width=25).grid(row=0, column=3, sticky="ew", padx=5, pady=5)
        ttk.Entry(form, textvariable=self.precio_var, width=25).grid(row=1, column=1, sticky="ew", padx=5, pady=5)
        ttk.Entry(form, textvariable=self.stock_var, width=25).grid(row=1, column=3, sticky="ew", padx=5, pady=5)
        ttk.Entry(form, textvariable=self.cantidad_var, width=25).grid(row=2, column=1, sticky="ew", padx=5, pady=5)
        ttk.Entry(form, textvariable=self.descuento_var, width=25).grid(row=2, column=3, sticky="ew", padx=5, pady=5)
        ttk.Entry(form, textvariable=self.cupon_var, width=25).grid(row=3, column=1, sticky="ew", padx=5, pady=5)
        ttk.Checkbutton(form, text="Premium Customer", variable=self.premium_var).grid(row=3, column=3, sticky="w", padx=5, pady=5)

        self.extra1_label = ttk.Label(form, text="")
        self.extra2_label = ttk.Label(form, text="")
        self.extra1_label.grid(row=4, column=0, sticky="w", padx=5, pady=5)
        self.extra2_label.grid(row=4, column=2, sticky="w", padx=5, pady=5)

        self.extra1_entry = ttk.Entry(form, textvariable=self.extra1_var, width=25)
        self.extra2_entry = ttk.Entry(form, textvariable=self.extra2_var, width=25)
        self.extra1_entry.grid(row=4, column=1, sticky="ew", padx=5, pady=5)
        self.extra2_entry.grid(row=4, column=3, sticky="ew", padx=5, pady=5)

        buttons = ttk.Frame(form)
        buttons.grid(row=5, column=0, columnspan=4, pady=10, sticky="ew")

        ttk.Button(buttons, text="Add to Cart", command=self.add_to_cart).pack(side="left", padx=5)
        ttk.Button(buttons, text="Show Cart", command=self.show_cart).pack(side="left", padx=5)
        ttk.Button(buttons, text="Calculate Total", command=self.calculate_total).pack(side="left", padx=5)
        ttk.Button(buttons, text="Clear Cart", command=self.clear_cart).pack(side="left", padx=5)

        output_frame = ttk.LabelFrame(main, text="Cart Details", padding=15)
        output_frame.pack(fill="both", expand=True, pady=15)

        self.output = tk.Text(output_frame, wrap="word", font=("Consolas", 10))
        self.output.pack(fill="both", expand=True)

        for i in range(4):
            form.columnconfigure(i, weight=1)

    def _update_extra_fields(self):
        tipo = self.tipo_var.get()
        self.extra1_var.set("")
        self.extra2_var.set("")
        if tipo == "Electronics":
            self.extra1_label.config(text="Brand")
            self.extra2_label.config(text="Warranty (months)")
        elif tipo == "Food":
            self.extra1_label.config(text="Category")
            self.extra2_label.config(text="Expiration (days)")
        else:
            self.extra1_label.config(text="Size")
            self.extra2_label.config(text="Season")

    def _create_product(self):
        tipo = self.tipo_var.get()
        nombre = self.nombre_var.get().strip()
        precio = float(self.precio_var.get())
        stock = int(self.stock_var.get())
        extra1 = self.extra1_var.get().strip()
        extra2 = self.extra2_var.get().strip()

        if not nombre:
            raise ValueError("Name is required.")
        if precio <= 0:
            raise ValueError("Price must be greater than zero.")
        if stock <= 0:
            raise ValueError("Stock must be greater than zero.")
        if not extra1 or not extra2:
            raise ValueError("Complete the additional product fields.")

        if tipo == "Electronics":
            return ProductoElectronico(nombre, precio, stock, extra1, int(extra2))
        if tipo == "Food":
            return ProductoAlimento(nombre, precio, stock, extra1, int(extra2))
        return ProductoRopa(nombre, precio, stock, extra1, extra2)

    def add_to_cart(self):
        try:
            producto = self._create_product()
            cantidad = int(self.cantidad_var.get())
            descuento = float(self.descuento_var.get())
            cupon = float(self.cupon_var.get())
            premium = self.premium_var.get()
            self.carrito.agregar_producto(producto, cantidad, descuento, cupon, premium)
            messagebox.showinfo("Success", "Product added to cart successfully.")
            self.show_cart()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def show_cart(self):
        self.output.delete("1.0", tk.END)
        if not self.carrito.items:
            self.output.insert(tk.END, "The cart is currently empty.\n")
            return
        for i, descripcion in enumerate(self.carrito.obtener_descripciones(), start=1):
            self.output.insert(tk.END, f"{i}. {descripcion}\n\n")

    def calculate_total(self):
        total = self.carrito.calcular_total()
        self.output.insert(tk.END, f"Total Purchase Amount: ${total:.2f}\n")

    def clear_cart(self):
        self.carrito.vaciar()
        self.output.delete("1.0", tk.END)
        self.output.insert(tk.END, "Cart cleared successfully.\n")


if __name__ == "__main__":
    root = tk.Tk()
    app = TiendaVirtualApp(root)
    root.mainloop()